import java.awt.Color;
import java.awt.Dimension;
import javax.swing.JFrame;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.data.category.DefaultCategoryDataset;

public class GraficoBarras {

  public static void main(String[] args) {
  
    // Creamos los datos para el gráfico
    DefaultCategoryDataset dataset = new DefaultCategoryDataset();
    dataset.setValue(20, "Ventas", "Enero");
    dataset.setValue(50, "Ventas", "Febrero");
    dataset.setValue(30, "Ventas", "Marzo");
    dataset.setValue(40, "Ventas", "Abril");
    dataset.setValue(10, "Ventas", "Mayo");
    
    // Creamos el gráfico
    JFreeChart chart = ChartFactory.createBarChart(
        "Ventas por mes", // Título del gráfico
        "Mes", // Etiqueta del eje x
        "Ventas", // Etiqueta del eje y
        dataset, // Datos para el gráfico
        PlotOrientation.VERTICAL, // Orientación del gráfico
        true, // Mostrar leyenda
        true, // Mostrar tooltips
        false // Mostrar urls
    );
    
    // Personalizamos el gráfico
    chart.setBackgroundPaint(Color.white);
    chart.getTitle().setPaint(Color.black);
    chart.getCategoryPlot().getDomainAxis().setTickLabelPaint(Color.black);
    chart.getCategoryPlot().getRangeAxis().setTickLabelPaint(Color.black);
    
    // Creamos el panel para mostrar el gráfico
    ChartPanel chartPanel = new ChartPanel(chart);
    chartPanel.setPreferredSize(new Dimension(500, 300));
    
    // Creamos la ventana para mostrar el panel
    JFrame ventana = new JFrame("Gráfico de barras");
    ventana.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    ventana.getContentPane().add(chartPanel);
    ventana.pack();
    ventana.setVisible(true);
    
  }

}
